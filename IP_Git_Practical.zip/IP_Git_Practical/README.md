# Internet Programming Practical: Git and GitHub

## 1. Open the project
Extract this ZIP, open the `IP_Git_Practical` folder in VS Code, then open Terminal > New Terminal.

## 2. Check Git
Run these commands one at a time:
```bash
git
git --version
```

## 3. Initialize the repository
Run from inside this project folder:
```bash
git init
git status
```

## 4. Add and commit the file
```bash
git add index.html
git status
git commit -m "First commit"
```

If Git asks you to set your identity, run these commands with your own details:
```bash
git config --global user.name "Your Name"
git config --global user.email "your-email@example.com"
```
Then repeat the commit command.

## 5. Connect to your GitHub repository
First create a new repository on https://github.com/ named `ip1-exp2`.
Do not add a README or other files on GitHub if this local folder already has files.

Replace YOUR-USERNAME with your GitHub username:
```bash
git remote add origin https://github.com/YOUR-USERNAME/ip1-exp2.git
git remote -v
git branch -M main
git push -u origin main
```

If `origin` already exists, use:
```bash
git remote set-url origin https://github.com/YOUR-USERNAME/ip1-exp2.git
```

## Important
I prepared the project files, but publishing to GitHub requires your own GitHub login/authentication. Never share your password or one-time codes.
